#ifndef __ANIMOS_H__
#define __ANIMOS_H__
#include <stdio.h>
#include <stdbool.h>

/*
Pre: -
Post: que el viento, humedad y animos de legolas y gimli esten en un valor valido. 
*/ 

void animos(int* viento , int* humedad , char* animo_legolas , char* animo_gimli); 


#endif /*__ANIMOS_H__*/